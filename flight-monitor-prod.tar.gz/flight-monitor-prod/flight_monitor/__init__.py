"""OneTwoTrip flight price monitor."""
